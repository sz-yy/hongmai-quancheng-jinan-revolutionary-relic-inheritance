const team = require('../../data/team.js');
const timeline = require('../../data/timeline.js');
const spirit = require('../../data/spirit.js');

Page({
  data: {
    stats: team.stats,
    timeline: timeline,
    route: spirit.route,
    sections: [
      { no: '01', title: '革命文物深度寻访', desc: '走访 5 处纪念地，整理 12 份文物档案，用双脚丈量红色泉城。' },
      { no: '02', title: '创新传播与当代叙事', desc: '以数字孪生、互动答题等新方式，让革命文物"活"在当下。' },
      { no: '03', title: '精神传承与时代践行', desc: '采集 8 段口述史，把红色血脉写进青春答卷。' }
    ],
    hero: '/assets/hero/hero-jiefangge.jpg'
  },
  goRelics() { wx.switchTab({ url: '/pages/relics/relics' }); },
  goQuiz() { wx.switchTab({ url: '/pages/quiz/quiz' }); }
});
