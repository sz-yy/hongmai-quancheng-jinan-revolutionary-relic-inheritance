const relics = require('../../data/relics.js');

Page({
  data: {
    filter: 'all',
    list: relics,
    all: relics
  },
  onFilter(e) {
    const f = e.currentTarget.dataset.f;
    const list = f === 'all' ? this.data.all : this.data.all.filter((r) => r.type === f);
    this.setData({ filter: f, list });
  },
  goDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: '/pkgRelics/detail/detail?id=' + id });
  }
});
