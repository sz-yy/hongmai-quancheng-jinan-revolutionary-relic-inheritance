const cloud = require('../../utils/cloud.js');

const MAX_LEN = 200;

Page({
  data: {
    list: [],
    loading: true,
    nickname: '',
    content: '',
    maxLen: MAX_LEN,
    likedIds: [],
    submitting: false
  },

  onLoad() {
    this.loadLikes();
    this.refresh();
  },

  refresh() {
    this.setData({ loading: true });
    cloud.fetchMessages().then((list) => {
      const liked = this.data.likedIds;
      const arr = list.map((m) => Object.assign({}, m, { liked: liked.indexOf(m._id) >= 0 }));
      this.setData({ list: arr, loading: false });
    });
  },

  onPullDownRefresh() {
    this.refresh();
    wx.stopPullDownRefresh();
  },

  loadLikes() {
    try {
      this.setData({ likedIds: wx.getStorageSync('hmqc_likes') || [] });
    } catch (e) {}
  },
  saveLikes() {
    try {
      wx.setStorageSync('hmqc_likes', this.data.likedIds);
    } catch (e) {}
  },

  onNick(e) { this.setData({ nickname: e.detail.value }); },
  onContent(e) { this.setData({ content: e.detail.value }); },

  like(e) {
    const id = e.currentTarget.dataset.id;
    const isLocal = e.currentTarget.dataset.local;
    const liked = this.data.likedIds.slice();
    const idx = liked.indexOf(id);
    const list = this.data.list.slice();
    const pos = list.findIndex((m) => m._id === id);
    if (idx >= 0) {
      liked.splice(idx, 1);
      if (pos >= 0) list[pos].likes = Math.max(0, (list[pos].likes || 0) - 1);
      if (pos >= 0) list[pos].liked = false;
    } else {
      liked.push(id);
      if (pos >= 0) list[pos].likes = (list[pos].likes || 0) + 1;
      if (pos >= 0) list[pos].liked = true;
    }
    this.setData({ likedIds: liked, list });
    this.saveLikes();
    if (!isLocal) {
      cloud.likeMessage(id, false).catch(() => {});
    }
  },

  submit() {
    const content = (this.data.content || '').trim();
    if (!content) {
      wx.showToast({ title: '请先写下感悟', icon: 'none' });
      return;
    }
    if (content.length > MAX_LEN) {
      wx.showToast({ title: '不超过 ' + MAX_LEN + ' 字', icon: 'none' });
      return;
    }
    if (this.data.submitting) return;
    this.setData({ submitting: true });
    cloud.addMessage(this.data.nickname, content).then((item) => {
      if (item && item._id && item._local) {
        const list = [item].concat(this.data.list);
        this.setData({ list, content: '', submitting: false });
      } else {
        this.refresh();
        this.setData({ content: '', submitting: false });
      }
      wx.showToast({ title: '已提交', icon: 'success' });
    }).catch(() => {
      this.setData({ submitting: false });
      wx.showToast({ title: '提交失败，请重试', icon: 'none' });
    });
  }
});
