const team = require('../../data/team.js');
const oral = require('../../data/oral.js');
const spirit = require('../../data/spirit.js');

Page({
  data: {
    team: team,
    oral: oral,
    spiritMap: spirit.map
  },
  goBoard() {
    wx.switchTab({ url: '/pages/board/board' });
  }
});
