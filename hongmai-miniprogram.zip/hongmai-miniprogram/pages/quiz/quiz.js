const { quiz, levelOf } = require('../../data/quiz.js');
const storage = require('../../utils/storage.js');
const poster = require('../../utils/poster.js');

const TOTAL = 10;

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = a[i]; a[i] = a[j]; a[j] = t;
  }
  return a;
}

Page({
  data: {
    stage: 'entry', // entry | quiz | result
    best: null,
    questions: [],
    idx: 0,
    selected: -1,
    showAnswer: false,
    score: 0,
    wrong: [],
    startTime: 0,
    result: null
  },

  onLoad() {
    this.setData({ best: storage.getBest() });
  },

  start() {
    const qs = shuffle(quiz).slice(0, TOTAL).map((q) => {
      const opts = shuffle(q.options.map((t, i) => ({ t, i })));
      return { q: q.q, options: opts, answer: q.answer, explain: q.explain };
    });
    this.setData({
      stage: 'quiz',
      questions: qs,
      idx: 0,
      selected: -1,
      showAnswer: false,
      score: 0,
      wrong: [],
      startTime: Date.now()
    });
  },

  choose(e) {
    if (this.data.showAnswer) return;
    const i = e.currentTarget.dataset.i;
    const cur = this.data.questions[this.data.idx];
    const correct = cur.answer;
    const chosen = cur.options[i];
    const isRight = chosen.i === correct;
    const wrong = this.data.wrong.slice();
    if (!isRight) {
      const rightOpt = cur.options.find((o) => o.i === correct);
      wrong.push({
        q: cur.q,
        my: chosen.t,
        right: rightOpt ? rightOpt.t : '',
        explain: cur.explain
      });
    }
    this.setData({
      selected: i,
      showAnswer: true,
      score: this.data.score + (isRight ? 1 : 0),
      wrong
    });
  },

  next() {
    const idx = this.data.idx + 1;
    if (idx >= this.data.questions.length) {
      this.finish();
    } else {
      this.setData({ idx, selected: -1, showAnswer: false });
    }
  },

  finish() {
    const total = this.data.questions.length;
    const score = this.data.score;
    const time = Math.round((Date.now() - this.data.startTime) / 1000);
    const level = levelOf(score, total);
    const best = storage.setBest({ score, total, level, time });
    this.setData({
      stage: 'result',
      result: { score, total, level, time, wrong: this.data.wrong },
      best
    });
  },

  again() {
    this.start();
  },

  genCard() {
    const that = this;
    wx.createSelectorQuery()
      .select('#scoreCanvas')
      .fields({ node: true, size: true })
      .exec((res) => {
        if (!res || !res[0] || !res[0].node) {
          wx.showToast({ title: '生成失败', icon: 'none' });
          return;
        }
        const canvas = res[0].node;
        const ctx = canvas.getContext('2d');
        const W = 600, H = 720;
        const dpr = (wx.getWindowInfo && wx.getWindowInfo().pixelRatio) || 2;
        canvas.width = W * dpr;
        canvas.height = H * dpr;
        ctx.scale(dpr, dpr);
        poster.drawScoreCard(ctx, W, H, {
          score: that.data.result.score,
          total: that.data.result.total,
          level: that.data.result.level,
          time: that.data.result.time
        });
        wx.canvasToTempFilePath({
          canvas,
          success(r) {
            wx.saveImageToPhotosAlbum({
              filePath: r.tempFilePath,
              success() { wx.showToast({ title: '已保存到相册' }); },
              fail() { wx.showToast({ title: '请允许相册权限', icon: 'none' }); }
            });
          },
          fail() { wx.showToast({ title: '生成失败', icon: 'none' }); }
        });
      });
  },

  onShareAppMessage() {
    const r = this.data.result;
    return {
      title: '我在红脉泉城知识闯关得了 ' + (r ? r.score : '?') + ' 分，来挑战！',
      path: '/pages/quiz/quiz'
    };
  }
});
