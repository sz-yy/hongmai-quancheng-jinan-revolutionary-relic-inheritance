// 红脉泉城 · 答题成绩本地存储
const KEY = 'hmqc_quiz_best';

function getBest() {
  try {
    return wx.getStorageSync(KEY) || null;
  } catch (e) {
    return null;
  }
}

// 仅当本次成绩更高时更新历史最佳
function setBest(record) {
  try {
    const best = getBest();
    if (!best || record.score > best.score) {
      wx.setStorageSync(KEY, record);
      return record;
    }
    return best;
  } catch (e) {
    return null;
  }
}

module.exports = { getBest, setBest };
