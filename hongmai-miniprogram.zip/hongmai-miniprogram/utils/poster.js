// 红脉泉城 · 成绩卡片绘制（Canvas 2D）
// drawScoreCard(ctx, W, H, data)
// data: { score, total, level, time }
function drawScoreCard(ctx, W, H, data) {
  ctx.fillStyle = '#F5EFE0';
  ctx.fillRect(0, 0, W, H);

  // 顶部红色标题带
  ctx.fillStyle = '#B91C1C';
  ctx.fillRect(0, 0, W, 150);
  ctx.fillStyle = '#FFFFFF';
  ctx.textAlign = 'center';
  ctx.font = 'bold 38px sans-serif';
  ctx.fillText('红脉泉城 · 知识闯关', W / 2, 62);
  ctx.font = '22px sans-serif';
  ctx.fillText('济南革命历史知识测评', W / 2, 108);

  // 得分
  ctx.fillStyle = '#B91C1C';
  ctx.font = 'bold 110px sans-serif';
  ctx.fillText(String(data.score), W / 2, 300);
  ctx.fillStyle = '#5F5E5A';
  ctx.font = '24px sans-serif';
  ctx.fillText('得分 / 共 ' + data.total + ' 题', W / 2, 348);

  // 称号
  ctx.fillStyle = '#2B2B2B';
  ctx.font = 'bold 36px sans-serif';
  ctx.fillText(data.level, W / 2, 430);

  // 用时
  ctx.fillStyle = '#5F5E5A';
  ctx.font = '24px sans-serif';
  ctx.fillText('用时 ' + data.time + ' 秒', W / 2, 480);

  // 分隔线
  ctx.strokeStyle = '#C8A45C';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(60, 540);
  ctx.lineTo(W - 60, 540);
  ctx.stroke();

  // 底部署名
  ctx.fillStyle = '#C8A45C';
  ctx.font = '22px sans-serif';
  ctx.fillText('山东大学 · 芯溯红迹实践队', W / 2, H - 50);
}

module.exports = { drawScoreCard };
