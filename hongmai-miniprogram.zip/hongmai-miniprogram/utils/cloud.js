// 红脉泉城 · 留言板云开发封装（含本地降级）
// 云可用：读写云数据库 messages 集合（status 字段预留审核）。
// 云不可用：退回到本地兜底 + 本机临时提交，保证演示可跑。
const localBoard = require('../data/board.js');

function getDB() {
  try {
    if (!wx.cloud || !wx.cloud.database) return null;
    return wx.cloud.database();
  } catch (e) {
    return null;
  }
}

function formatTime(ts) {
  if (!ts) return '';
  let d;
  if (typeof ts === 'object' && ts.$date) {
    d = new Date(ts.$date);
  } else if (ts instanceof Date) {
    d = ts;
  } else {
    d = new Date(ts);
  }
  if (isNaN(d.getTime())) return '';
  const p = (n) => (n < 10 ? '0' + n : '' + n);
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
}

function enrichLocal(item) {
  return {
    _id: item._id,
    nickname: item.nickname || '匿名访客',
    content: item.content,
    createTime: item.createTime,
    timeText: formatTime(item.createTime),
    likes: item.likes || 0,
    _local: true
  };
}

// 读取留言：云可用则取 status='approved' 倒序；否则取本地兜底
function fetchMessages() {
  return new Promise((resolve) => {
    const db = getDB();
    if (!db) {
      return resolve(localBoard.list.map(enrichLocal));
    }
    db.collection('messages')
      .where({ status: 'approved' })
      .orderBy('createTime', 'desc')
      .limit(50)
      .get()
      .then((res) => {
        const arr = (res.data || []).map((m) => ({
          _id: m._id,
          nickname: m.nickname || '匿名访客',
          content: m.content,
          createTime: m.createTime,
          timeText: formatTime(m.createTime),
          likes: m.likes || 0,
          _local: false
        }));
        resolve(arr.length ? arr : localBoard.list.map(enrichLocal));
      })
      .catch(() => resolve(localBoard.list.map(enrichLocal)));
  });
}

// 提交留言：云可用则写入（默认 approved 便于演示即上墙，status 字段预留审核）；
// 否则返回一个本地条目，由页面在内存中追加展示。
function addMessage(nickname, content) {
  return new Promise((resolve, reject) => {
    const db = getDB();
    if (!db) {
      const item = enrichLocal({
        _id: 'local_' + Date.now(),
        nickname: nickname || '匿名访客',
        content: content,
        createTime: Date.now(),
        likes: 0,
        _local: true
      });
      return resolve(item);
    }
    db.collection('messages')
      .add({
        data: {
          nickname: nickname || '匿名访客',
          content: content,
          status: 'approved',
          likes: 0,
          createTime: db.serverDate()
        }
      })
      .then(() => resolve({ _id: 'cloud', _local: false }))
      .catch((err) => reject(err));
  });
}

// 点赞：云可用则自增；本地则在页面内存中处理并回调
function likeMessage(id, isLocal) {
  return new Promise((resolve, reject) => {
    if (isLocal) {
      // 本地点赞由页面直接修改内存并持久化，这里仅回执
      return resolve(true);
    }
    const db = getDB();
    if (!db) return resolve(true);
    const _ = db.command;
    db.collection('messages')
      .doc(id)
      .update({ data: { likes: _.inc(1) } })
      .then(() => resolve(true))
      .catch((err) => reject(err));
  });
}

module.exports = { fetchMessages, addMessage, likeMessage, formatTime };
