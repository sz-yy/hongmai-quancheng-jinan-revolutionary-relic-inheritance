const FRAME_COUNT = 24;

Page({
  data: {
    frames: [],
    frameIndex: 0,
    useFrames: false,
    preview: '/pkgTank/tank-preview.png',
    autoplay: true
  },

  onLoad() {
    const frames = [];
    for (let i = 1; i <= FRAME_COUNT; i++) {
      frames.push('/pkgTank/frames/frame_' + (i < 10 ? '0' : '') + i + '.jpg');
    }
    this.setData({ frames });
    const first = frames[0];
    wx.getImageInfo({
      src: first,
      success: () => {
        this.setData({ useFrames: true });
        this.startAuto();
      },
      fail: () => {
        this.setData({ useFrames: false });
      }
    });
  },

  startAuto() {
    this.clearAuto();
    this._timer = setInterval(() => {
      if (this.data.autoplay) {
        this.setData({ frameIndex: (this.data.frameIndex + 1) % FRAME_COUNT });
      }
    }, 90);
  },
  clearAuto() {
    if (this._timer) {
      clearInterval(this._timer);
      this._timer = null;
    }
  },
  onTouchStart(e) {
    this.clearAuto();
    this._sx = e.touches[0].clientX;
  },
  onTouchMove(e) {
    if (!this.data.useFrames) return;
    const dx = e.touches[0].clientX - this._sx;
    if (Math.abs(dx) >= 12) {
      const step = dx > 0 ? -1 : 1;
      this.setData({ frameIndex: (this.data.frameIndex + step + FRAME_COUNT) % FRAME_COUNT, _sx: e.touches[0].clientX });
    }
  },
  restart() {
    this.setData({ autoplay: true });
    this.startAuto();
  },
  onUnload() {
    this.clearAuto();
  }
});
