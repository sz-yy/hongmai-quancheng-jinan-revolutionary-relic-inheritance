# -*- coding: utf-8 -*-
"""生成 tabBar 图标（5 页 × 常态/选中 = 10 个 PNG，81×81）。
常态为灰，选中为中国红。纯 Pillow 矢量绘制后 4× 超采样降采样抗锯齿。"""
import os
from PIL import Image, ImageDraw

S = 4
N = 81
size = N * S
GRAY = (140, 140, 140, 255)
RED = (185, 28, 28, 255)
OUT = os.path.join(os.path.dirname(__file__), "..", "assets", "tabbar")


def canvas():
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img)


def finish(img, name):
    img = img.resize((N, N), Image.LANCZOS)
    os.makedirs(OUT, exist_ok=True)
    img.save(os.path.join(OUT, name))


def home(color):
    img, d = canvas()
    w = 12
    d.line([(55, 148), (162, 62), (269, 148)], fill=color, width=w, joint="curve")
    d.line([(92, 148), (92, 256), (232, 256), (232, 148)], fill=color, width=w)
    d.rectangle((148, 200, 200, 256), outline=color, width=w)
    finish(img, "home.png" if color == GRAY else "home-active.png")


def relics(color):
    img, d = canvas()
    w = 12
    d.rounded_rectangle((78, 86, 246, 236), radius=14, outline=color, width=w)
    d.ellipse((196, 104, 232, 140), fill=color)
    d.polygon([(88, 224), (150, 150), (196, 206), (232, 168), (244, 224)], fill=color)
    finish(img, "relics.png" if color == GRAY else "relics-active.png")


def quiz(color):
    img, d = canvas()
    w = 14
    d.line([(95, 250), (228, 104)], fill=color, width=w, joint="curve")
    d.polygon([(228, 104), (206, 118), (244, 124)], fill=color)
    d.line([(95, 250), (112, 266)], fill=color, width=w)
    finish(img, "quiz.png" if color == GRAY else "quiz-active.png")


def about(color):
    img, d = canvas()
    w = 12
    d.ellipse((66, 66, 258, 258), outline=color, width=w)
    d.ellipse((150, 108, 174, 132), fill=color)
    d.line([(162, 150), (162, 232)], fill=color, width=w)
    finish(img, "about.png" if color == GRAY else "about-active.png")


def board(color):
    img, d = canvas()
    w = 12
    d.rounded_rectangle((60, 72, 262, 206), radius=26, outline=color, width=w)
    d.polygon([(108, 206), (108, 250), (150, 206)], fill=color)
    finish(img, "board.png" if color == GRAY else "board-active.png")


if __name__ == "__main__":
    for fn in (home, relics, quiz, about, board):
        fn(GRAY)
        fn(RED)
    print("tabBar 图标已生成：", os.path.abspath(OUT))
