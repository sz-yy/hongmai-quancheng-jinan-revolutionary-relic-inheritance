# -*- coding: utf-8 -*-
"""伪 3D：GLB -> 24 帧环绕序列图（600x600 / q76）。
纯 numpy + Pillow 软渲染：顶点投影 + 画家算法排序 + 圆盘 splat + 贴图采样 + Lambert 着色。
不依赖 trimesh / pyrender / OpenGL。首帧计时，若单帧过慢则中止并回退静态预览图。
"""
import os, sys, time, struct, json, io, base64
import numpy as np
from PIL import Image

GLB = r"C:/Users/张学林/Desktop/img/hongmai-quancheng/assets/models/relic-meritorious-tank.glb"
OUT = r"C:/Users/张学林/Desktop\img\hongmai-miniprogram\pkgTank\frames"
FRAMES = 24
SIZE = 600
R = 2                      # splat 半径（像素）
ELEV = 12 * np.pi / 180    # 俯仰倾角
BG = (245, 239, 224)       # 米白背景，与页面一致
PROBE_ONLY = False         # 调试：仅渲染首帧计时


def load_glb(path):
    with open(path, 'rb') as f:
        data = f.read()
    magic, ver, length = struct.unpack('<4sII', data[:12])
    assert magic == b'glTF', 'not a glb'
    off = 12
    js = None
    binn = None
    while off < len(data):
        clen, ctype = struct.unpack('<I4s', data[off:off + 8])
        cdata = data[off + 8:off + 8 + clen]
        if ctype == b'JSON':
            js = json.loads(cdata.decode('utf-8'))
        elif ctype == b'BIN\x00':
            binn = cdata
        off += 8 + clen
    return js, binn


CT = {5126: ('<f4', 4), 5123: ('<u2', 2), 5125: ('<u4', 4), 5121: ('<u1', 1)}
TYPE = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}


def read_accessor(js, binn, ai):
    acc = js['accessors'][ai]
    bv = js['bufferViews'][acc['bufferView']]
    dt, nb = CT[acc['componentType']]
    nc = TYPE[acc['type']]
    start = (bv.get('byteOffset', 0) + acc.get('byteOffset', 0))
    arr = np.frombuffer(binn, dtype=np.dtype(dt), count=acc['count'] * nc, offset=start)
    return arr.reshape(acc['count'], nc)


def read_texture_image(js, binn):
    # 取第一个带 baseColorTexture 的材质
    mat = None
    for m in js.get('materials', []):
        if 'pbrMetallicRoughness' in m and 'baseColorTexture' in m['pbrMetallicRoughness']:
            mat = m; break
    if mat is None:
        return None
    ti = mat['pbrMetallicRoughness']['baseColorTexture']['index']
    src = js['textures'][ti]['source']
    img = js['images'][src]
    if 'bufferView' in img:
        bv = js['bufferViews'][img['bufferView']]
        raw = binn[bv['byteOffset']:bv['byteOffset'] + bv['byteLength']]
        return Image.open(io.BytesIO(raw)).convert('RGB')
    if 'uri' in img and img['uri'].startswith('data:'):
        b64 = img['uri'].split(',', 1)[1]
        return Image.open(io.BytesIO(base64.b64decode(b64))).convert('RGB')
    return None


def main():
    os.makedirs(OUT, exist_ok=True)
    js, binn = load_glb(GLB)
    pos = read_accessor(js, binn, js['meshes'][0]['primitives'][0]['attributes']['POSITION'])
    nrm = read_accessor(js, binn, js['meshes'][0]['primitives'][0]['attributes']['NORMAL'])
    uv = read_accessor(js, binn, js['meshes'][0]['primitives'][0]['attributes']['TEXCOORD_0'])
    tex = read_texture_image(js, binn)
    texarr = np.asarray(tex, dtype=np.float32) if tex else None
    th, tw = (texarr.shape[0], texarr.shape[1]) if texarr is not None else (1, 1)

    # 居中归一化
    cmin = pos.min(0); cmax = pos.max(0)
    center = (cmin + cmax) / 2
    ext = (cmax - cmin).max()
    p = (pos - center) / ext * (SIZE * 0.62)
    n = nrm / (np.linalg.norm(nrm, axis=1, keepdims=True) + 1e-8)
    uv = uv - np.floor(uv)  # 防越界
    tx = (uv[:, 0] * (tw - 1)).astype(np.int32)
    ty = ((1.0 - uv[:, 1]) * (th - 1)).astype(np.int32)
    if texarr is not None:
        col = texarr[ty, tx].astype(np.float32)
    else:
        col = np.full((len(p), 3), 200, dtype=np.float32)

    L = np.array([0.35, 0.45, 0.82]); L = L / np.linalg.norm(L)
    ndl = np.clip(n @ L, 0, 1)
    shade = (0.30 + 0.70 * ndl)[:, None]
    vcol = np.clip(col * shade, 0, 255).astype(np.uint8)

    cx = cy = SIZE / 2.0
    zoom = 1.0
    # 倾角矩阵（绕 X）
    cphi, sphi = np.cos(ELEV), np.sin(ELEV)

    # 偏移模板
    d = np.arange(-R, R + 1)
    ddx, ddy = np.meshgrid(d, d)
    ddx = ddx.ravel().astype(np.int32)
    ddy = ddy.ravel().astype(np.int32)
    tmpl = (ddx ** 2 + ddy ** 2) <= R * R

    def render(theta):
        ct, st = np.cos(theta), np.sin(theta)
        x = p[:, 0] * ct + p[:, 2] * st
        z = -p[:, 0] * st + p[:, 2] * ct
        y = p[:, 1]
        # 倾角
        y2 = y * cphi - z * sphi
        z2 = y * sphi + z * cphi
        sx = (cx + x * zoom).astype(np.int32)
        sy = (cy - y2 * zoom).astype(np.int32)
        depth = z2
        order = np.argsort(depth)  # 远 -> 近
        buf = np.full((SIZE, SIZE, 3), BG, dtype=np.uint8)
        cov = np.zeros((SIZE, SIZE), dtype=bool)
        for i in order:
            xi = int(sx[i]); yi = int(sy[i])
            xs = (xi + ddx)[tmpl]
            ys = (yi + ddy)[tmpl]
            m = (xs >= 0) & (xs < SIZE) & (ys >= 0) & (ys < SIZE)
            xs = xs[m]; ys = ys[m]
            if xs.size == 0:
                continue
            buf[ys, xs] = vcol[i]
            cov[ys, xs] = True
        return buf, cov

    t0 = time.time()
    buf0, _ = render(0.0)
    dt = time.time() - t0
    print('单帧渲染耗时 %.2f s' % dt)
    if dt > 35 and not PROBE_ONLY:
        print('[跳过] 单帧过慢，回退静态预览图。')
        return

    if PROBE_ONLY:
        Image.fromarray(buf0).save(os.path.join(OUT, 'frame_probe.png'))
        print('probe 已保存，退出。')
        return

    for f in range(FRAMES):
        theta = 2 * np.pi * f / FRAMES
        buf, _ = render(theta)
        im = Image.fromarray(buf)
        im.save(os.path.join(OUT, 'frame_%02d.jpg' % (f + 1)), 'JPEG', quality=76, optimize=True)
        print('frame %02d / %02d' % (f + 1, FRAMES))
    print('全部帧完成，耗时 %.1f s' % (time.time() - t0))


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--probe':
        PROBE_ONLY = True
    main()
