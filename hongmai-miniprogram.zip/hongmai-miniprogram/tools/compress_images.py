# -*- coding: utf-8 -*-
"""压缩文物图片：主包缩略图(300px/q70) + 分包大图(750px/q72) + 首页横幅(750×500/q75)。"""
import os
from PIL import Image, ImageOps

SRC = r"C:/Users/张学林/Desktop/img/hongmai-quancheng/assets/images"
ROOT = os.path.join(os.path.dirname(__file__), "..")
THUMB_DIR = os.path.join(ROOT, "assets", "thumbs")
LARGE_DIR = os.path.join(ROOT, "pkgRelics", "images")
HERO_DIR = os.path.join(ROOT, "assets", "hero")
for d in (THUMB_DIR, LARGE_DIR, HERO_DIR):
    os.makedirs(d, exist_ok=True)

# (源文件名, 输出基名) —— 与 data/relics.js 中的 image/thumb 字段对应
RELIcs = [
    ("relic-jiefangge.jpg", "relic-jiefangge"),
    ("relic-meritorious-tank.jpg", "relic-meritorious-tank"),
    ("relic-wangjinmei.jpg", "relic-wangjinmei"),
    ("mao-calligraphy.jpg", "mao-calligraphy"),
    ("relic-wangyaowu-pistol.jpg", "relic-wangyaowu-pistol"),
    ("relic-jinan-memorial.jpg", "relic-jinan-memorial"),
    ("relic-hero-mountain.jpg", "relic-hero-mountain"),
    ("wartime-currency.jpg", "wartime-currency"),
    ("party-early-history.jpg", "party-early-history"),
    ("early-party-branches.jpg", "early-party-branches"),
    ("changjiang-song-plaque.jpg", "changjiang-song-plaque"),
    ("president-hua-gang.jpg", "president-hua-gang"),
    ("laboratory-glassware.jpg", "laboratory-glassware"),
    ("left-wing-culture.jpg", "left-wing-culture"),
]


def fit_resize(im, long_edge):
    w, h = im.size
    if w >= h:
        nw = long_edge
        nh = max(1, round(h * long_edge / w))
    else:
        nh = long_edge
        nw = max(1, round(w * long_edge / h))
    return im.resize((nw, nh), Image.LANCZOS)


total = 0
for src, base in RELIcs:
    p = os.path.join(SRC, src)
    im = Image.open(p).convert("RGB")
    im = ImageOps.exif_transpose(im)
    t = fit_resize(im, 300)
    tp = os.path.join(THUMB_DIR, base + ".jpg")
    t.save(tp, "JPEG", quality=70, optimize=True, progressive=True)
    l = fit_resize(im, 750)
    lp = os.path.join(LARGE_DIR, base + ".jpg")
    l.save(lp, "JPEG", quality=72, optimize=True, progressive=True)
    total += os.path.getsize(tp) + os.path.getsize(lp)

# 首页横幅：中心裁剪 3:2
HEROES = [("relic-jiefangge.jpg", "hero-jiefangge"), ("relic-jinan-memorial.jpg", "hero-jinan")]
for src, base in HEROES:
    im = Image.open(os.path.join(SRC, src)).convert("RGB")
    im = ImageOps.exif_transpose(im)
    w, h = im.size
    tw, th = 3, 2
    if w / h > tw / th:
        nh = h
        nw = round(h * tw / th)
        x = (w - nw) // 2
        box = (x, 0, x + nw, h)
    else:
        nw = w
        nh = round(w * th / tw)
        y = (h - nh) // 2
        box = (0, y, w, y + nh)
    im = im.crop(box).resize((750, 500), Image.LANCZOS)
    im.save(os.path.join(HERO_DIR, base + ".jpg"), "JPEG", quality=75, optimize=True)

print("图片压缩完成。主包+分包新增约 %.2f KB" % (total / 1024))
