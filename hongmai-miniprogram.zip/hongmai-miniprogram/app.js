// 红脉泉城 · 小程序入口
const { cloudEnv } = require('./utils/config.js');

App({
  globalData: {
    cloudReady: false,
    cloudEnv: cloudEnv || ''
  },

  onLaunch() {
    if (!wx.cloud) {
      console.error('[红脉泉城] 当前基础库版本过低，无法使用云开发能力（留言板将降级为本地演示）。');
      return;
    }
    try {
      const initOpts = { traceUser: true };
      if (cloudEnv) initOpts.env = cloudEnv;
      wx.cloud.init(initOpts);
      this.globalData.cloudReady = true;
    } catch (e) {
      console.warn('[红脉泉城] 云开发初始化失败，留言板将使用本地降级模式：', e);
    }
  }
});
