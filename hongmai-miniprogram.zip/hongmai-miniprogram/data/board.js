// 红脉泉城 · 留言板本地兜底数据（云开发不可用时展示）
// 注意：createTime 为毫秒时间戳；likes 为初始点赞数。
const list = [
  { _id: 'local_1', nickname: '张学林', content: '把文物背后的故事讲给更多人听，是我们这代人的责任。', createTime: 1783216800000, likes: 12, _local: true },
  { _id: 'local_2', nickname: '赵芃喆', content: '站在解放阁下，才真正懂得"敢于胜利"四个字的分量。', createTime: 1783837800000, likes: 9, _local: true },
  { _id: 'local_3', nickname: '苗润泽', content: '用代码和镜头，让红色记忆在云端延续。', createTime: 1784423700000, likes: 15, _local: true }
];

module.exports = { list };
