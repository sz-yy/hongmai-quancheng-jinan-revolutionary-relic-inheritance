const relics = require('../../data/relics.js');
const spirit = require('../../data/spirit.js');

Page({
  data: {
    relic: null,
    protectWays: spirit.protectWays,
    open: false
  },
  onLoad(q) {
    const relic = relics.find((r) => r.id === q.id) || relics[0];
    this.setData({ relic });
    wx.setNavigationBarTitle({ title: relic.name });
  },
  preview() {
    if (this.data.relic) {
      wx.previewImage({ urls: [this.data.relic.image], current: this.data.relic.image });
    }
  },
  go3d() {
    wx.navigateTo({ url: '/pkgTank/tank/tank' });
  },
  toggle() {
    this.setData({ open: !this.data.open });
  }
});
